# (C) Copyright 2016 Comsecuris UG
# https://sourceware.org/gdb/onlinedocs/gdb/Events-In-Python.html#Events-In-Python

from __future__ import print_function
import os
import socket
import struct
import json

GHIDRA_BRIGE_IP = '127.0.0.1'
GHIDRA_BRIDGE_PORT = 2305
GHIDRA_ANSWER_PORT = 2306

INIT_BP_WORKAROUND = False
DEBUG = 1

TEXT_START = 'Start of text: '
TEXT_END   = 'End of text: '

socket.setdefaulttimeout(0.1)

class GhidraBridge(gdb.Command):
    def __init__(self):
        super (GhidraBridge, self).__init__("ghidrabridge", gdb.COMMAND_USER)
        self._ghidra_ip = GHIDRA_BRIGE_IP
        self._ghidra_port = GHIDRA_BRIDGE_PORT
        self._init_bps = []
        self._img_base = None
        self._img_reloc = False
        self._socket = None
        self._connected = False

    def connect(self):
        print("connect")
        if self._connected:
            return

        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._socket.connect((self._ghidra_ip, self._ghidra_port))
        self._connected = True
        
    def disconnect(self):
        print("disconnect")
        if self._connected:
            self._socket.close()
            self._connected = False

    def hdl_stop_event(self, event):
        print("hdl_stop_event")
        # in case we want to ignore all breakpoints that were set before the ghidrabridge was launched.
        if isinstance(event, gdb.BreakpointEvent) and event.breakpoint in self._init_bps:
            return

        if self._img_base == None and self._img_reloc == True:
            self.get_relocation()

        pc = self.get_pc()

        if self._img_reloc:
            print("adjusted pc from 0x%x to 0x%x (base: 0x%x)\n" %(pc, pc-self._img_reloc, self._img_base))
            pc = pc - self._img_base
            
        self.update_cursor_to(pc)

    def update_cursor_to(self, address):
        message = {
            "type":"CURSOR",
            "data":[ {"CURSOR":{"ADDRESS":hex(address) }} ],
            }
        self.tell_ghidra(json.dumps(message))

    def get_relocation(self):
            val = gdb.execute('info proc stat', to_string=True)
            s_text = val.find(TEXT_START)
            e_text = val.find(TEXT_END)
            if s_text == -1:
                    print("could not determine image relocation information\n")
                    self._img_reloc = False
                    return

            reloc = val[s_text + len(TEXT_START) : e_text - 1]
            self._img_base = int(reloc, 16)
            print("using 0x%x as text relocation\n" %(self._img_base))

    def get_pc(self):
            val = gdb.selected_frame().pc()
            return val
    
    def tell_ghidra(self, message):
        print("tell_ghidra")
        try:
            self.connect()
        except Exception as e:
            self.disconnect()
            self.connect()
        
        self._socket.send(bytes(message, 'UTF-8'))
        

    def invoke(self, arg, from_tty):
            argv = arg.split(' ')
            if len(argv) < 1:
                    print("ghidrabridge <ip:port> [reloc_text]")
                    return

            target = argv[0].split(':')

            if not '.' in target[0] or len(target) < 2:
                    print("please specify ip:port combination")
                    return

            self._ghidra_ip = target[0]
            self._ghidra_port = int(target[1])
            print("ghidrabridge: using ip: %s port: %d\n" %(self._ghidra_ip, self._ghidra_port))

            self.connect()

            if len(argv) >= 2 and argv[1] == 'reloc_text':
                    self._img_reloc = True

            if INIT_BP_WORKAROUND:
                    self._init_bps = gdb.breakpoints()

            gdb.events.stop.connect(self.hdl_stop_event)
    
GhidraBridge()
